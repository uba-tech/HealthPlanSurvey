﻿angular.module('SurveyWrangler', ['ngRoute', 'ngResource', 'ui.grid']);
